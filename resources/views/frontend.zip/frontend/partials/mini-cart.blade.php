<div class="cart-wrapper mini-cart" id="mini-cart">
    <div class="cart-header d-flex">
        <span class="close-icon"><i class="fa fa-arrow-right"></i></span>
        <p>YOUR CART</p>
    </div>
    <div class="content">
        <div class="loader"></div>
    </div>
</div>