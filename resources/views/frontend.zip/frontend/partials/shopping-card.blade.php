
<a href="{{ route('checkout') }}">
    <div class="cart-shopping-btn mc-toggler" id="cart">
        <i class="fa fa-shopping-cart "></i>
        <div class="total-items">
            <p class="count text-dark">0 item(s)</p>
        </div>
    </div>
</a>
