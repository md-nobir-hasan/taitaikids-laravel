 <header>
        <div class="header-top-wrapper">
            <div class="wrapper-container">
                <div class="header-top-bar d-flex justify-content-between align-items-center">
                    <div id="search" class="search-bar">
                        <input type="text" name="search" value="" placeholder="Search for products">
                        <button class="fa fa-search-plus" aria-hidden="true"></button>
                    </div>
                    <div class="top-nav-right d-flex">
                        <div class="offers">
                            <a href="#"><i class="fa fa-bookmark"
                                    aria-hidden="true"></i><span>Offers</span></a>
                        </div>
                        <div class="brands">
                            <a href="#"><i class="fa fa-tag"
                                    aria-hidden="true"></i><span>Brands</span></a>
                        </div>
                        <div class="login">
                            <a href="#"><i class="fa fa-sign-in"></i><span>Login</span></a>
                        </div>
                    </div>
                    <div class="overlay-bg login-popup"></div>
                </div>
            </div>
        </div>
    </header>
